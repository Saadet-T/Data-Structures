#include"List.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;
void List::yaz() {
	Node* current = start;
	while (current != NULL)
	{
		cout << current->name << "<-->";
		current = current->next;
	}
        cout << "\b\b\b\b    ";
}

void List::add(string name, int id) {
	if (start == NULL) {
		this->start = new Node(name);
	}
	else {
		Node* current = start;
		for (int i = 0; i < id; i++)
		{
			if (current->next != NULL)
				current = current->next;
		}
		int k = 0;

		if (current->next == NULL) {
			current->next = new Node(name);
			current->next->previous = current;
			return;
		}

		while (current->next != NULL) {
			k++;
			current = current->next;
		}
		Node* temp = new Node(current->name);
		current->next = temp;
		temp->previous = current;
		while (k != 0) {
			current->name = current->previous->name;
			current = current->previous;
			k--;
		}
		current->name = name;
	}
}
void List::dlt(int id) {
	Node* current = start;
	for (int i = 0; i < id; i++) {
		if (current->next == NULL)
			break;
		current = current->next;
	}
	while (current->next != NULL) {
		current->name = current->next->name;
		current = current->next;
	}
	current->previous->next = NULL;
	delete(current);

}