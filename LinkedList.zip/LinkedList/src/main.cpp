/**
* @file main.cpp
* @description E veya S belirtilmesiyle birlikte silmek veya eklemek
* @course �kinci ��retim A grubu
* @assignment Birinci �dev 9.11.2021
* @date 9.11.2021
* @author b191210028 saadet.tokuoglu@ogr.sakarya.edu.tr
*/
#include <iostream>
#include <fstream>
#include <cstdlib>
#include"List.h"

using namespace std;
int main()
{
    List* list = new List();
    fstream file;
    string word, t, q, filename;

    filename = "Veri.txt";

    file.open(filename.c_str());

    while (!file.eof())
    {
        getline(file, word);
        
        
        if (word[0] == 'E') { 
            word = word.substr(2, word.size() - 3);
            list->add(word.substr(word.find_first_of('#') + 1, word.size() - word.find_first_of('#')), stoi(word.substr(0, word.find_first_of('#'))));
        }
        else {
            word = word.substr(2, word.size() - 3);
            list->dlt(stoi(word));
        }
    
    }
        list->yaz();

}
