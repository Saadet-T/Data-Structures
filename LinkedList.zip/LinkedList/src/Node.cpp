#include"Node.h"
using namespace std;

Node::Node(string name) {
	this->name = name;
	this->next = NULL;
	this->previous = NULL;
}