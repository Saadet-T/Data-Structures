/**
* @file Node.h
* @description Node(d���m�m�z� ) tan�mlamak �ncesi sonras�n� belirtmek
* @course �kinci ��retim A grubu
* @assignment Birinci �dev 9.11.2021
* @date 9.11.2021
* @author b191210028 saadet.tokuoglu@ogr.sakarya.edu.tr
*/

using namespace std;
#include <string>

class Node {
public:
	string name;
	Node* next;
	Node* previous;
	Node(string name);
};