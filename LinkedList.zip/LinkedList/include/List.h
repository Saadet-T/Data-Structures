/**
* @file List.h
* @description Listeyi olu�turmak
* @course �kinci ��retim A grubu
* @assignment Birinci �dev 9.11.2021
* @date 9.11.2021
* @author b191210028 saadet.tokuoglu@ogr.sakarya.edu.tr
*/

#ifndef LIST_H
#define LIST_H
using namespace std;
#include"Node.h"

class List {
public:
	Node* start;
	void yaz();
	void add(string name, int id);
	void dlt(int id);
};
#endif